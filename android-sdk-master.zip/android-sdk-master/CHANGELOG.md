Moved to [https://github.com/watson-developer-cloud/android-sdk/wiki/Changelog](https://github.com/watson-developer-cloud/android-sdk/wiki/Changelog)
